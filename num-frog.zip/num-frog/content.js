// Num Frog: only numpad keys are ever touched. Num Lock is never remapped.
let map = {};
const active = {}; // numpad code -> {to, mods} while held, so keyup matches keydown

const load = () => chrome.storage.sync.get({ numFrog: {} }, (d) => { map = d.numFrog; });
load();
chrome.storage.onChanged.addListener(load);

const isNumpad = (code) => code.startsWith('Numpad') && code !== 'NumLock';

function deepActive() {
  let a = document.activeElement;
  while (a && a.shadowRoot && a.shadowRoot.activeElement) a = a.shadowRoot.activeElement;
  return a || document.body;
}

function send(type, target, to, mods, repeat) {
  const key = (mods.shift && !to.shift && /^[a-z]$/.test(to.key)) ? to.key.toUpperCase() : to.key;
  return target.dispatchEvent(new KeyboardEvent(type, {
    key, code: to.code, ctrlKey: mods.ctrl, altKey: mods.alt, shiftKey: mods.shift || !!to.viaShift,
    metaKey: mods.meta, repeat: !!repeat, bubbles: true, cancelable: true, composed: true,
  }));
}

// Synthetic key events don't type by themselves, so do the default action manually.
function applyDefault(el, key, mods) {
  if (mods.ctrl || mods.alt || mods.meta) return;
  const isField = el.matches && el.matches('input, textarea');
  if (!(isField || el.isContentEditable)) return;

  if (key.length === 1) {
    const ch = (mods.shift && /^[a-z]$/.test(key)) ? key.toUpperCase() : key;
    document.execCommand('insertText', false, ch);
  } else if (key === 'Backspace') document.execCommand('delete');
  else if (key === 'Delete') document.execCommand('forwardDelete');
  else if (key === 'Enter') {
    if (el.tagName === 'TEXTAREA') document.execCommand('insertText', false, '\n');
    else if (el.isContentEditable) document.execCommand('insertParagraph');
    else if (el.form) el.form.requestSubmit();
  } else if (isField && ['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(key)) {
    try {
      const s = el.selectionStart, e2 = el.selectionEnd, len = el.value.length;
      const pos = key === 'Home' ? 0 : key === 'End' ? len
        : key === 'ArrowLeft' ? (s !== e2 ? s : Math.max(0, s - 1))
        : (s !== e2 ? e2 : Math.min(len, e2 + 1));
      el.setSelectionRange(pos, pos);
    } catch (_) { /* input type without selection support */ }
  } else if (el.isContentEditable && ['ArrowLeft', 'ArrowRight'].includes(key)) {
    getSelection().modify(mods.shift ? 'extend' : 'move', key === 'ArrowLeft' ? 'backward' : 'forward', 'character');
  }
}

window.addEventListener('keydown', (e) => {
  if (!e.isTrusted || !isNumpad(e.code)) return;
  const to = map[e.code];
  if (!to) return;
  e.preventDefault();
  e.stopImmediatePropagation();
  const mods = {
    ctrl: to.ctrl || e.ctrlKey, alt: to.alt || e.altKey,
    shift: to.shift || e.shiftKey, meta: to.meta || e.metaKey,
  };
  active[e.code] = { to, mods };
  const target = deepActive();
  if (send('keydown', target, to, mods, e.repeat)) applyDefault(target, to.key, mods);
}, true);

window.addEventListener('keyup', (e) => {
  if (!e.isTrusted) return;
  const a = active[e.code];
  if (!a) return;
  delete active[e.code];
  e.preventDefault();
  e.stopImmediatePropagation();
  send('keyup', deepActive(), a.to, a.mods, false);
}, true);
