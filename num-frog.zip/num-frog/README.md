# Num Frog

1. Open chrome://extensions and turn on **Developer mode**.
2. Click **Load unpacked** and select this folder.
3. Click the frog icon, click a numpad key, then press the key it should become.
4. Reload tabs that were already open.
