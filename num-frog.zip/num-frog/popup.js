const $ = (id) => document.getElementById(id);

// Numpad layout: [code, label, row, col, rowSpan, colSpan]
const KEYS = [
  ['NumLock', 'Num Lock', 1, 1, 1, 1], ['NumpadDivide', '/', 1, 2, 1, 1],
  ['NumpadMultiply', '*', 1, 3, 1, 1], ['NumpadSubtract', '-', 1, 4, 1, 1],
  ['Numpad7', '7', 2, 1, 1, 1], ['Numpad8', '8', 2, 2, 1, 1], ['Numpad9', '9', 2, 3, 1, 1],
  ['NumpadAdd', '+', 2, 4, 2, 1],
  ['Numpad4', '4', 3, 1, 1, 1], ['Numpad5', '5', 3, 2, 1, 1], ['Numpad6', '6', 3, 3, 1, 1],
  ['Numpad1', '1', 4, 1, 1, 1], ['Numpad2', '2', 4, 2, 1, 1], ['Numpad3', '3', 4, 3, 1, 1],
  ['NumpadEnter', 'Enter', 4, 4, 2, 1],
  ['Numpad0', '0', 5, 1, 1, 2], ['NumpadDecimal', '.', 5, 3, 1, 1],
];
const LABEL = Object.fromEntries(KEYS.map((k) => [k[0], k[1]]));
const NAMES = {
  Enter: '↵', Backspace: '⌫', Delete: 'Del', Escape: 'Esc', Tab: '⇥', ' ': 'Space',
  ArrowUp: '↑', ArrowDown: '↓', ArrowLeft: '←', ArrowRight: '→', CapsLock: 'Caps',
};
const MODS = ['Control', 'Shift', 'Alt', 'Meta'];

let map = {};
let selected = null;
let timer = null;

function fmt(t) {
  const parts = [];
  if (t.ctrl) parts.push('Ctrl');
  if (t.alt) parts.push('Alt');
  if (t.shift) parts.push('Shift');
  if (t.meta) parts.push('Meta');
  parts.push(NAMES[t.key] || t.key);
  return parts.join('+');
}

function setMsg(text, kind) {
  const d = $('dialog');
  d.textContent = text;
  d.className = 'dialog px' + (kind ? ' ' + kind : '');
}
function idle() {
  setMsg(selected ? 'Press a key' : 'Click a key', selected ? 'wait' : '');
}
function flashOk(text) {
  clearTimeout(timer);
  setMsg(text, 'ok');
  timer = setTimeout(idle, 1000);
}

function render() {
  const pad = $('pad');
  pad.textContent = '';
  for (const [code, label, r, c, rs, cs] of KEYS) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'k';
    b.style.gridArea = `${r} / ${c} / span ${rs} / span ${cs}`;
    if (code === 'NumLock') {
      b.classList.add('numlock');
      b.disabled = true;           // untouchable
      b.title = 'Num Lock can’t be remapped';
      b.textContent = label;
    } else {
      const t = map[code];
      const main = document.createElement('span');
      main.className = 'main';
      if (t) {
        const txt = fmt(t);
        main.textContent = txt;
        if (txt.length > 3) main.classList.add('small');
        b.classList.add('mapped');
        const g = document.createElement('span');
        g.className = 'ghost';
        g.textContent = label;
        b.append(main, g);
      } else {
        main.textContent = label;
        b.append(main);
      }
      if (code === selected) b.classList.add('sel');
      b.setAttribute('aria-label', t ? `${label}, remapped to ${fmt(t)}` : label);
      b.onclick = () => {
        selected = selected === code ? null : code;
        clearTimeout(timer);
        render();
        idle();
      };
    }
    pad.append(b);
  }
}

const save = () => chrome.storage.sync.set({ numFrog: map });

document.addEventListener('keydown', (e) => {
  if (!selected) return;
  if (e.code === 'NumLock' || MODS.includes(e.key)) return; // Num Lock is untouchable
  e.preventDefault();
  const from = selected;
  if (e.code === from) {
    delete map[from];
    flashOk(`Reset ${LABEL[from]} to default`);
  } else {
    // Shift + key (e.g. Shift+, ) is stored as the shifted character itself ("<"), not as Shift and ","
    const shiftedChar = e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey && e.key.length === 1;
    map[from] = {
      key: e.key, code: e.code,
      ctrl: e.ctrlKey, alt: e.altKey, meta: e.metaKey,
      shift: shiftedChar ? false : e.shiftKey,
      viaShift: shiftedChar,
    };
    flashOk(`Remapped ${LABEL[from]} to “${fmt(map[from])}”`);
  }
  selected = null;
  save();
  render();
});

$('reset').onclick = () => {
  map = {};
  selected = null;
  save();
  render();
  flashOk('All keys reset to default');
};

chrome.storage.sync.get({ numFrog: {} }, (d) => {
  map = d.numFrog;
  render();
  idle();
});
